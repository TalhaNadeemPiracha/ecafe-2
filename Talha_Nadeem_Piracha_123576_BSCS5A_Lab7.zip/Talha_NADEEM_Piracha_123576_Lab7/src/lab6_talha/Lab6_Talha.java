package lab6_talha;
import java.sql.*;
import java.util.Properties;
import java.util.Scanner;


public class Lab6_Talha {
	

	
	public static void main( String[] args)
	{
		
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
		    Properties p = new Properties();
		    p.setProperty("user", "root");
		    p.setProperty("password", "teedees123");
		    p.setProperty("useSSL", "false");
		    p.setProperty("autoReconnect", "true");
		
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/ecafe", p);
			Statement statement = connection.createStatement();
			
			
	       String sql = "select * from menu";
	       PreparedStatement prep_statement = connection.prepareStatement(sql);
	       ResultSet rs = prep_statement.executeQuery(sql);
	       
	       while (rs.next()) {
	    	 //Retrieve by column name & Display values
	    	 System.out.print("ID: \t\t " + rs.getInt("id")+"\t");
	    	 System.out.print("Item: \t\t" + rs.getString("name")+"\t");
	    	 System.out.print("Price \t\t " + rs.getString("price")+"\t");
	    	 
	    	 }
               PreparedStatement preparedStatement=connection.prepareStatement ("INSERT INTO MENU(name, price, category) VALUES (?, ?, ?)");
               preparedStatement.setString(1, "Samosa");
               preparedStatement.setString(3, "Chicken nahari");
               preparedStatement.setInt(2, 85);
               
               preparedStatement.executeUpdate();
               
                       
               
               rs.close();
	    	 prep_statement.close();
	    	 connection.close();
	     
	       System.out.print("Select the order");
	       Scanner s=new Scanner(System.in);
	       int ss=s.nextInt();
               
               
               PreparedStatement prep_statement = connection.prepareStatement(sql);
	       ResultSet rs1 = prep_statement.executeQuery(sql);
               PreparedStatement preparedStatement2= connection.prepareStatement("SELECT name, category FROM MENU WHERE id=(?)");
               preparedStatement.setInt(2, 15);
               while(rs1.next()) {
	       
	      
	    	 
			
		}
                }

		catch (SQLException | ClassNotFoundException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
	}
}
		



